Up, Down, Right, Left - передвижение по одному тайлу.
(NumPad) Up, Down, Right, Left - непрерывное передвижение.
Esc - выход в меню.